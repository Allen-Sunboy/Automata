
// Generated from regex.g4 by ANTLR 4.12.0


#include "regexListener.h"


