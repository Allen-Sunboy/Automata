操作系统：Windows 10
架构：VS Code
编译：MinGW cmake

cases中的样例txt的换行都是LF，即\n，程序的多行处理也是由此处理。

